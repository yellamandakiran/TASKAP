package com.example.tasktick;

import java.util.Calendar;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.*;

public class MainActivity extends Activity {
    private LinearLayout list;
    private EditText taskInput;
    private TextView progress, counts;
    private JSONArray tasks;
    private android.content.SharedPreferences prefs;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("tasktick", MODE_PRIVATE);
        tasks = loadTasks();
        buildScreen();
        renderTasks();
        createChannel();
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 10);
        }
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density); }
    private TextView label(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        return t;
    }
    private void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this); root.setOrientation(1);
        root.setPadding(dp(20), dp(24), dp(20), dp(24)); root.setBackgroundColor(Color.rgb(246,248,251));
        scroll.addView(root);
        setContentView(scroll);

        TextView title = label("TaskTick", 28, Color.rgb(20,30,45), true);
        root.addView(title);
        TextView sub = label("Your simple daily checklist", 14, Color.DKGRAY, false);
        LinearLayout.LayoutParams subp = new LinearLayout.LayoutParams(-1,-2); subp.bottomMargin=dp(20); root.addView(sub,subp);

        LinearLayout card = new LinearLayout(this); card.setOrientation(1); card.setPadding(dp(16),dp(16),dp(16),dp(16));
        card.setBackground(roundBg(Color.WHITE, 18)); root.addView(card);
        progress = label("0% completed", 18, Color.rgb(20,30,45), true); card.addView(progress);
        counts = label("✓ 0 completed     ✕ 0 remaining", 13, Color.DKGRAY, false);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1,-2); cp.topMargin=dp(8); card.addView(counts,cp);

        LinearLayout addRow = new LinearLayout(this); addRow.setOrientation(0); addRow.setGravity(Gravity.CENTER_VERTICAL);
        taskInput = new EditText(this); taskInput.setSingleLine(true); taskInput.setHint("Enter a task");
        taskInput.setTextSize(15); taskInput.setPadding(dp(12),0,dp(12),0);
        addRow.addView(taskInput,new LinearLayout.LayoutParams(0,dp(52),1));
        Button add = new Button(this); add.setText("ADD"); add.setTextColor(Color.WHITE); add.setBackground(roundBg(Color.rgb(22,163,74),12));
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(dp(88),dp(48)); ap.leftMargin=dp(8); addRow.addView(add,ap);
        LinearLayout.LayoutParams arp = new LinearLayout.LayoutParams(-1,-2); arp.topMargin=dp(18); card.addView(addRow,arp);
        add.setOnClickListener(v -> addTask());

        TextView heading = label("MY TASKS", 13, Color.GRAY, true);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1,-2); hp.topMargin=dp(24); hp.bottomMargin=dp(8); root.addView(heading,hp);
        list = new LinearLayout(this); list.setOrientation(1); root.addView(list);

        Button reminder = new Button(this); reminder.setText("Set daily reminder");
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1,dp(52)); rp.topMargin=dp(18); root.addView(reminder,rp);
        reminder.setOnClickListener(v -> chooseReminder());

        Button cancel = new Button(this); cancel.setText("Turn off reminder");
        root.addView(cancel);
        cancel.setOnClickListener(v -> {
            ((AlarmManager)getSystemService(ALARM_SERVICE)).cancel(reminderPendingIntent());
            prefs.edit().remove("reminder_time").apply();
            Toast.makeText(this,"Daily reminder turned off",Toast.LENGTH_SHORT).show();
        });
    }

    private android.graphics.drawable.GradientDrawable roundBg(int color, int radius) {
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private JSONArray loadTasks() {
        try { return new JSONArray(prefs.getString("tasks","[]")); } catch(Exception e) { return new JSONArray(); }
    }
    private void saveTasks() { prefs.edit().putString("tasks",tasks.toString()).apply(); }
    private void addTask() {
        String s=taskInput.getText().toString().trim(); if(s.isEmpty()) return;
        JSONObject o=new JSONObject(); try { o.put("text",s); o.put("done",false); tasks.put(o); } catch(Exception ignored){}
        taskInput.setText(""); saveTasks(); renderTasks();
    }
    private void renderTasks() {
        list.removeAllViews(); int done=0;
        for(int i=0;i<tasks.length();i++) {
            final int index=i; JSONObject obj=tasks.optJSONObject(i); if(obj==null) continue;
            boolean checked=obj.optBoolean("done",false); if(checked) done++;
            LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(10),dp(7),dp(8),dp(7)); row.setBackground(roundBg(Color.WHITE,12));
            LinearLayout.LayoutParams rowp=new LinearLayout.LayoutParams(-1,-2); rowp.bottomMargin=dp(8); list.addView(row,rowp);
            CheckBox box=new CheckBox(this); box.setButtonTintList(android.content.res.ColorStateList.valueOf(checked?Color.rgb(22,163,74):Color.GRAY));
            box.setChecked(checked); row.addView(box);
            TextView text=label(obj.optString("text"),16,checked?Color.GRAY:Color.rgb(30,41,59),false);
            if(checked) text.setPaintFlags(text.getPaintFlags() | 16);
            row.addView(text,new LinearLayout.LayoutParams(0,-2,1));
            TextView mark=label(checked?"✓":"✕",20,checked?Color.rgb(22,163,74):Color.rgb(220,38,38),true);
            row.addView(mark);
            box.setOnCheckedChangeListener((button,isChecked)->{
                try { tasks.getJSONObject(index).put("done",isChecked); } catch(Exception ignored){}
                saveTasks(); renderTasks();
            });
            row.setOnLongClickListener(v->{ new AlertDialog.Builder(this).setMessage("Delete this task?")
                .setNegativeButton("Cancel",null).setPositiveButton("Delete",(d,w)->{tasks.remove(index);saveTasks();renderTasks();}).show(); return true;});
        }
        int total=tasks.length(), remaining=total-done, percent=total==0?0:(done*100/total);
        progress.setText(percent+"% completed");
        counts.setText("✓ "+done+" completed     ✕ "+remaining+" remaining");
        if(total==0) list.addView(label("No tasks yet. Add your first task above.",14,Color.GRAY,false));
    }
    private void chooseReminder() {
        java.util.Calendar now=java.util.Calendar.getInstance();
        new TimePickerDialog(this,(view,hour,minute)->{
            java.util.Calendar cal=java.util.Calendar.getInstance();
            cal.set(java.util.Calendar.HOUR_OF_DAY,hour); cal.set(java.util.Calendar.MINUTE,minute); cal.set(java.util.Calendar.SECOND,0);
            if(cal.getTimeInMillis()<=System.currentTimeMillis()) cal.add(java.util.Calendar.DAY_OF_YEAR,1);
            AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);
            prefs.edit().putLong("reminder_time",cal.getTimeInMillis()).apply();
            am.setInexactRepeating(AlarmManager.RTC_WAKEUP,cal.getTimeInMillis(),AlarmManager.INTERVAL_DAY,reminderPendingIntent());
            Toast.makeText(this,String.format("Daily reminder set for %02d:%02d",hour,minute),Toast.LENGTH_LONG).show();
        },now.get(Calendar.HOUR_OF_DAY),now.get(Calendar.MINUTE),false).show();
    }
    private PendingIntent reminderPendingIntent() {
        Intent i=new Intent(this,ReminderReceiver.class);
        return PendingIntent.getBroadcast(this,101,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }
    private void createChannel() {
        if(Build.VERSION.SDK_INT>=26) {
            NotificationChannel ch=new NotificationChannel("tasktick_reminders","Task reminders",NotificationManager.IMPORTANCE_DEFAULT);
            ch.setDescription("Daily reminders to review your tasks");
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
    }
}
