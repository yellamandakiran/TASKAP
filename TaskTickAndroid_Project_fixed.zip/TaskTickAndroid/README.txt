TASKTICK ANDROID APP

This is an Android Studio project for a simple personal checklist.

FEATURES
- Add tasks
- Tap a checkbox to mark completed
- Green tick for completed and red cross for remaining
- Progress percentage and completed/remaining counts
- Tasks saved locally on the phone
- Set a repeating daily reminder notification
- Long-press a task to delete it

BUILD THE APK
1. Install Android Studio on a computer.
2. Open Android Studio and choose Open.
3. Select the TaskTickAndroid folder (the folder containing settings.gradle).
4. Allow Gradle sync to finish. Android Studio may download the Android SDK and Gradle plugin.
5. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
6. When complete, click "locate" in the notification.
   APK output is normally app/build/outputs/apk/debug/app-debug.apk.

INSTALL ON YOUR ANDROID PHONE
1. Transfer app-debug.apk to your phone.
2. Open the APK file.
3. If prompted, allow your file manager/browser to install unknown apps.
4. Tap Install, then open TaskTick.
5. Allow notifications when asked.
6. In TaskTick, tap Set daily reminder and choose a time.

NOTES
- This workspace does not include the Android SDK/Gradle build environment, so it contains the source project rather than a precompiled APK.
- Reminder delivery uses Android's inexact daily alarm scheduling; battery saver and device settings can affect exact delivery time.
- Tasks are stored locally on the device and are not uploaded.
- Long-press a task row to delete it.
