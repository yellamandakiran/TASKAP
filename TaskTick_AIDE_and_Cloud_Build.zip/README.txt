TASKTICK — ANDROID CHECKLIST APP

This is the TaskTick Android source project.

CLOUD BUILD FROM YOUR PHONE (RECOMMENDED)
1. Sign in to https://github.com/ in Chrome.
2. Create a new repository named TaskTick. Choose Private if you prefer.
3. In the repository, choose Add file > Upload files.
4. Upload the CONTENTS of this folder (including the hidden .github folder).
   Important: the .github/workflows/build-apk.yml file must be uploaded at that exact path.
5. Commit the uploaded files to the main branch.
6. Open the repository's Actions tab.
7. Select "Build TaskTick APK" and tap Run workflow if it has not started automatically.
8. Open the newest successful workflow run.
9. Under Artifacts, download TaskTick-debug-apk.
10. Extract the downloaded artifact ZIP. It contains app-debug.apk.
11. Tap app-debug.apk on your phone and install it. If Android asks, allow your browser or file manager to install unknown apps.

AIDE OPTION
AIDE can build simple Java/XML Android projects, but its documentation says full Gradle support is not yet available for Android Studio projects. This project uses Gradle and Android Gradle Plugin 8.7.3, so AIDE may not be able to build it as-is. See:
https://android-ide.com/tutorial_androidstudio.html

PROJECT FEATURES
- Add tasks
- Tap checkboxes to mark completed
- Green check for completed and red cross for pending
- Progress and completed/remaining counts
- Tasks stored locally on the phone
- Daily reminder notification
- Long-press a task to delete

NOTES
- This is a debug APK for personal testing/sideloading.
- The cloud workflow builds the APK on GitHub-hosted runners; no Android SDK or laptop is required locally.
- Keep the repository private if you do not want your source project publicly visible.
