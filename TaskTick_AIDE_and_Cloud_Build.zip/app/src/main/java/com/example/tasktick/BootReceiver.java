package com.example.tasktick;
import android.content.*;
public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        // Android may clear scheduled alarms after restart. Set a new daily reminder
        // only if the user previously saved a reminder time.
        android.content.SharedPreferences p=context.getSharedPreferences("tasktick",Context.MODE_PRIVATE);
        long when=p.getLong("reminder_time",0);
        if(when>0) {
            if (when <= System.currentTimeMillis()) when += android.app.AlarmManager.INTERVAL_DAY;
            android.app.AlarmManager am=(android.app.AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
            android.content.Intent i=new android.content.Intent(context,ReminderReceiver.class);
            android.app.PendingIntent pi=android.app.PendingIntent.getBroadcast(context,101,i,
                android.app.PendingIntent.FLAG_UPDATE_CURRENT|android.app.PendingIntent.FLAG_IMMUTABLE);
            am.setInexactRepeating(android.app.AlarmManager.RTC_WAKEUP,when,android.app.AlarmManager.INTERVAL_DAY,pi);
        }
    }
}
