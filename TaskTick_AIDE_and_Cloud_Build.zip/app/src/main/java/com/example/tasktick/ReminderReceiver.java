package com.example.tasktick;
import android.app.*;
import android.content.*;
import android.os.Build;
public class ReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        Notification.Builder b = Build.VERSION.SDK_INT>=26 ?
            new Notification.Builder(context,"tasktick_reminders") : new Notification.Builder(context);
        b.setSmallIcon(android.R.drawable.ic_dialog_info)
         .setContentTitle("TaskTick reminder")
         .setContentText("Take a moment to check your remaining tasks.")
         .setAutoCancel(true);
        ((NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE)).notify(101,b.build());
    }
}
